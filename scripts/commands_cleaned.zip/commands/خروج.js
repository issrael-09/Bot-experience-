module.exports.config = {
  name: "خروج",
  version: "1.0.0",
  hasPermssion: 2,
  credits: "Cleaned by ChatGPT",
  description: "إخراج البوت من المجموعة",
  commandCategory: "إدارة",
  usages: ".خروج",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  try {
    await api.removeUserFromGroup(api.getCurrentUserID(), threadID);
  } catch (e) {
    return api.sendMessage("❌ تعذر إخراج البوت من المجموعة: " + e.message, threadID, messageID);
  }
};
