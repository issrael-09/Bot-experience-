const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "groupNameProtection.json");

function loadData() {
  try {
    if (!fs.existsSync(DATA_FILE)) return {};
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return {};
  }
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf8");
}

module.exports.config = {
  name: "اسم",
  version: "1.0.0",
  hasPermssion: 2,
  credits: "Cleaned by ChatGPT",
  description: "تغيير اسم المجموعة وحمايته",
  commandCategory: "إدارة",
  usages: ".اسم [الاسم] | .اسم حماية on/off",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const data = loadData();

  if (!args.length) {
    return api.sendMessage(
      "الاستخدام:\n" +
      "• .اسم [الاسم] — تغيير اسم المجموعة\n" +
      "• .اسم حماية on — حماية الاسم الحالي\n" +
      "• .اسم حماية off — إيقاف حماية الاسم",
      threadID, messageID
    );
  }

  const sub = String(args[0]).toLowerCase();

  if (sub === "حماية" || sub === "protect") {
    const state = String(args[1] || "").toLowerCase();

    if (state === "on" || state === "تشغيل") {
      try {
        const info = await api.getThreadInfo(threadID);
        data[threadID] = {
          enabled: true,
          name: info.threadName || ""
        };
        saveData(data);
        return api.sendMessage("🛡️ تم تفعيل حماية اسم المجموعة.", threadID, messageID);
      } catch (e) {
        return api.sendMessage("❌ تعذر تفعيل الحماية: " + e.message, threadID, messageID);
      }
    }

    if (state === "off" || state === "ايقاف") {
      delete data[threadID];
      saveData(data);
      return api.sendMessage("⛔ تم إيقاف حماية اسم المجموعة.", threadID, messageID);
    }

    return api.sendMessage("استخدم: .اسم حماية on أو .اسم حماية off", threadID, messageID);
  }

  const newName = args.join(" ").trim();
  if (!newName) return api.sendMessage("❌ اكتب الاسم الجديد.", threadID, messageID);

  try {
    await api.setTitle(newName, threadID);
    if (data[threadID]?.enabled) {
      data[threadID].name = newName;
      saveData(data);
    }
    return api.sendMessage("✅ تم تغيير اسم المجموعة إلى: " + newName, threadID, messageID);
  } catch (e) {
    return api.sendMessage("❌ فشل تغيير اسم المجموعة: " + e.message, threadID, messageID);
  }
};

module.exports.handleEvent = async function ({ api, event }) {
  if (!event.isGroup || event.type !== "change_thread_name") return;

  const data = loadData();
  const protection = data[event.threadID];
  if (!protection?.enabled || !protection.name) return;

  try {
    const info = await api.getThreadInfo(event.threadID);
    if ((info.threadName || "") !== protection.name) {
      await api.setTitle(protection.name, event.threadID);
    }
  } catch {}
};
