module.exports.config = {
  name: "nickname",
  version: "1.0.0",
  hasPermssion: 2,
  credits: "Replit Assistant",
  description: "تغيير كنية عضو أو الكل في القروب",
  commandCategory: "إدارة",
  usages: ".nickname 1 [رد على رسالة عضو] | .nickname all [رد على البوت بالكنية]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, messageReply } = event;
  const sub = (args[0] || "").toLowerCase();

  if (sub === "1") {
    if (!messageReply || !messageReply.senderID) {
      return api.sendMessage("⚠️ ارد على رسالة العضو الذي تريد تغيير كنيته.", threadID, messageID);
    }
    const newNick = args.slice(1).join(" ").trim();
    if (!newNick) {
      return api.sendMessage("⚠️ اكتب الكنية الجديدة بعد الرقم 1.\nمثال: .nickname 1 الملك", threadID, messageID);
    }
    const uid = String(messageReply.senderID);
    try {
      await api.changeNickname(newNick, threadID, uid);
      return api.sendMessage(`✅ تـم تغيير الكنية إلى: ${newNick}`, threadID, messageID);
    } catch (e) {
      return api.sendMessage("❌ فشل تغيير الكنية: " + e.message, threadID, messageID);
    }
  }

  if (sub === "all") {
    const requestedNick = args.slice(1).join(" ").trim();
    const clearNickname = ["مسح", "حذف", "clear", "remove"].includes(requestedNick.toLowerCase());
    const newNick = clearNickname ? "" : requestedNick;
    if (!requestedNick) {
      return api.sendMessage("⚠️ اكتب الكنية الجديدة بعد all أو اكتب «مسح» لحذفها.\nمثال: .nickname all الملك", threadID, messageID);
    }
    try {
      const threadInfo = await api.getThreadInfo(threadID);
      const members = threadInfo.participantIDs || [];
      let success = 0;
      let failed = 0;

      for (let i = 0; i < members.length; i += 5) {
        const batch = members.slice(i, i + 5);
        const results = await Promise.all(batch.map(async (uid) => {
          try {
            await api.changeNickname(newNick, threadID, uid);
            return true;
          } catch (e) {
            return false;
          }
        }));

        for (const result of results) {
          if (result) success++;
          else failed++;
        }

        if (i + 5 < members.length) {
          await new Promise(r => setTimeout(r, 3000));
        }
      }

      return api.sendMessage(
        `✅ تـم ${clearNickname ? "مسح" : "تغيير"} كنيات ${success} عضو` +
        `${failed ? `\n❌ فشل: ${failed} عضو` : ""}`,
        threadID,
        messageID
      );
    } catch (e) {
      return api.sendMessage("❌ فشل تغيير الكنى: " + e.message, threadID, messageID);
    }
  }

  return api.sendMessage(
    "❓ الاستخدام:\n• .nickname 1 [الكنية] → رد على رسالة عضو\n• .nickname all [الكنية] → تغيير كنية الكل",
    threadID,
    messageID
  );
};
